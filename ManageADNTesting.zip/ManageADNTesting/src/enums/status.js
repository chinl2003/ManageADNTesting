export const StatusEnum = {
    Active: 'Hoạt động',
    Inactive: 'Không hoạt động'
};
