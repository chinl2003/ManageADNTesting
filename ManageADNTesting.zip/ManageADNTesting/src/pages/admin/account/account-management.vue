<template>
  <div class="p-4">
    <HeaderUserManagement />
    <MainUserList />
  </div>
</template>

<script setup>
import HeaderUserManagement from './header.vue';
import MainUserList from './main.vue';
</script>