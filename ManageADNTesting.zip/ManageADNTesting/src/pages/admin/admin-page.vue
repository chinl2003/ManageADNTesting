<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">Chào mừng đến trang quản trị</h1>
    <p class="text-gray-700">Đây là dashboard quản trị. Hãy chọn chức năng bên sidebar để bắt đầu quản lý hệ thống.</p>
  </div>
</template>

<script>
export default {}
</script>
