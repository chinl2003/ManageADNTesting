<template>
  <div class="p-4">
    <Header />
    <Main />
  </div>
</template>

<script setup>
import Header from './header.vue';
import Main from './main.vue';
</script>